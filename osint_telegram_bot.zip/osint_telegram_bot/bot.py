import asyncio
import ipaddress
import logging
import os
import re
import socket
from urllib.parse import quote, urlparse

import aiohttp
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder
from dotenv import load_dotenv
import phonenumbers

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN", "").strip()
HIBP_API_KEY = os.getenv("HIBP_API_KEY", "").strip()
ADMIN_IDS = {int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()}
MAX_PER_MINUTE = int(os.getenv("MAX_PER_MINUTE", "8"))

if not TOKEN:
    raise RuntimeError("Set BOT_TOKEN in .env")

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("osint-bot")
bot = Bot(TOKEN)
dp = Dispatcher()
user_actions = {}

MENU = [
    ("🔎 Никнейм", "username"),
    ("📱 Телефон", "phone"),
    ("✉️ Email", "email"),
    ("🌐 Домен / IP", "domain"),
    ("🧭 Telegram-профиль", "telegram"),
    ("🛡 Проверка утечек email", "leaks"),
]

def main_keyboard():
    kb = InlineKeyboardBuilder()
    for label, action in MENU:
        kb.button(text=label, callback_data=f"mode:{action}")
    kb.adjust(2, 2, 2)
    return kb.as_markup()

def safe(s: str, limit=3500):
    # Telegram HTML escaping
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))[:limit]

async def allowed(message: Message) -> bool:
    uid = message.from_user.id
    now = asyncio.get_running_loop().time()
    entries = [t for t in user_actions.get(uid, []) if now - t < 60]
    if len(entries) >= MAX_PER_MINUTE:
        await message.answer("Слишком много запросов. Подожди минуту и попробуй снова.")
        user_actions[uid] = entries
        return False
    entries.append(now)
    user_actions[uid] = entries
    return True

async def fetch_json(session, url, headers=None):
    try:
        async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=12)) as r:
            if r.status == 200:
                return await r.json(content_type=None)
            return {"_error": f"HTTP {r.status}"}
    except Exception as e:
        return {"_error": str(e)[:160]}

async def fetch_status(session, url):
    try:
        async with session.get(url, allow_redirects=True, timeout=aiohttp.ClientTimeout(total=8),
                               headers={"User-Agent": "PublicOSINTBot/1.0 (public profile availability checker)"}) as r:
            return r.status, str(r.url)
    except asyncio.TimeoutError:
        return None, url
    except Exception:
        return None, url

async def username_report(username):
    username = username.strip().lstrip("@")
    if not re.fullmatch(r"[A-Za-z0-9_.-]{2,40}", username):
        return "Некорректный ник. Используй 2–40 символов: буквы, цифры, точка, дефис или подчёркивание."
    sites = {
        "GitHub": f"https://github.com/{quote(username)}",
        "Reddit": f"https://www.reddit.com/user/{quote(username)}/",
        "GitLab": f"https://gitlab.com/{quote(username)}",
        "Pinterest": f"https://www.pinterest.com/{quote(username)}/",
        "Twitch": f"https://www.twitch.tv/{quote(username)}",
        "TikTok": f"https://www.tiktok.com/@{quote(username)}",
        "Instagram": f"https://www.instagram.com/{quote(username)}/",
        "X": f"https://x.com/{quote(username)}",
        "YouTube": f"https://www.youtube.com/@{quote(username)}",
    }
    timeout = aiohttp.ClientTimeout(total=12)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        results = await asyncio.gather(*(fetch_status(session, u) for u in sites.values()))
    lines = [f"🔎 <b>Публичный поиск по нику:</b> <code>{safe(username)}</code>", "",
             "Ссылки проверены на доступность, это не подтверждает владельца аккаунта."]
    for (site, url), (status, final_url) in zip(sites.items(), results):
        if status == 200:
            lines.append(f"✅ <a href=\"{safe(final_url)}\">{safe(site)}</a> — страница отвечает")
        elif status in (301, 302, 403, 429):
            lines.append(f"❔ <a href=\"{safe(url)}\">{safe(site)}</a> — статус {status}, нужна ручная проверка")
        elif status == 404:
            lines.append(f"➖ <a href=\"{safe(url)}\">{safe(site)}</a> — страница не найдена (возможно)")
        else:
            lines.append(f"❔ <a href=\"{safe(url)}\">{safe(site)}</a> — проверить вручную")
    return "\n".join(lines)

def phone_report(raw):
    try:
        parsed = phonenumbers.parse(raw, None)
        if not phonenumbers.is_possible_number(parsed):
            return "Номер выглядит некорректным. Введи международный формат, например +79991234567."
        valid = phonenumbers.is_valid_number(parsed)
        region = phonenumbers.region_code_for_number(parsed) or "не определена"
        carrier = phonenumbers.carrier.name_for_number(parsed, "ru") or "неизвестен"
        kind = phonenumbers.number_type(parsed)
        kinds = {
            phonenumbers.PhoneNumberType.MOBILE: "мобильный",
            phonenumbers.PhoneNumberType.FIXED_LINE: "стационарный",
            phonenumbers.PhoneNumberType.FIXED_LINE_OR_MOBILE: "стационарный/мобильный",
            phonenumbers.PhoneNumberType.TOLL_FREE: "бесплатный номер",
            phonenumbers.PhoneNumberType.PREMIUM_RATE: "платный номер",
        }
        return (
            "📱 <b>Проверка номера</b>\n"
            f"Нормализованный номер: <code>{safe(phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.E164))}</code>\n"
            f"Страна/регион: {safe(region)}\n"
            f"Валидный по плану нумерации: {'да' if valid else 'не подтверждено'}\n"
            f"Тип: {safe(kinds.get(kind, 'не определён'))}\n"
            f"Оператор по справочнику: {safe(carrier)}\n\n"
            "Это сведения о нумерации, а не установление личности владельца."
        )
    except Exception:
        return "Не смог разобрать номер. Введи его с кодом страны, например +79991234567."

def normalize_domain(raw):
    raw = raw.strip()
    if "://" in raw:
        parsed = urlparse(raw)
        host = parsed.hostname
    else:
        host = raw.split("/")[0].split(":")[0]
    if not host:
        return None
    host = host.rstrip(".").lower()
    if len(host) > 253 or not re.fullmatch(r"(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(\.([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?))*", host):
        return None
    return host

async def domain_report(raw):
    host = normalize_domain(raw)
    if not host:
        try:
            ip = ipaddress.ip_address(raw.strip())
        except ValueError:
            return "Не удалось распознать домен или IP."
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            return "Это частный, локальный или зарезервированный IP; публичная геолокация для него неприменима."
        async with aiohttp.ClientSession() as session:
            data = await fetch_json(session, f"http://ip-api.com/json/{ip}?fields=status,message,query,country,regionName,city,isp,org,as,timezone")
        if data.get("status") != "success":
            return f"Не удалось получить сведения об IP: {safe(str(data.get('message', data.get('_error', 'ошибка сервиса'))))}"
        return (
            f"🌐 <b>Публичные сведения об IP</b>\nIP: <code>{safe(str(ip))}</code>\n"
            f"Страна: {safe(data.get('country','—'))}\nРегион/город: {safe(data.get('regionName','—'))} / {safe(data.get('city','—'))}\n"
            f"Провайдер: {safe(data.get('isp','—'))}\nОрганизация: {safe(data.get('org','—'))}\nAS: {safe(data.get('as','—'))}\n"
            f"Часовой пояс: {safe(data.get('timezone','—'))}\n\nГеолокация IP приблизительная и не определяет точный адрес человека."
        )
    try:
        infos = await asyncio.get_running_loop().getaddrinfo(host, None, type=socket.SOCK_STREAM)
        ips = sorted({x[4][0] for x in infos})
    except Exception:
        ips = []
    async with aiohttp.ClientSession() as session:
        rdap = await fetch_json(session, f"https://rdap.org/domain/{quote(host)}")
    lines = [f"🌐 <b>Публичный отчёт по домену:</b> <code>{safe(host)}</code>"]
    lines.append("DNS A/AAAA: " + (", ".join(f"<code>{safe(x)}</code>" for x in ips) if ips else "не удалось получить"))
    if rdap.get("_error"):
        lines.append("RDAP/WHOIS: данные недоступны через выбранный сервис.")
    else:
        events = rdap.get("events", [])
        expiry = next((e.get("eventDate") for e in events if e.get("eventAction") in ("expiration", "expiry")), None)
        reg = next((e.get("eventDate") for e in events if e.get("eventAction") == "registration"), None)
        lines.append(f"Регистрация: {safe(reg or 'не указана')}")
        lines.append(f"Истечение регистрации: {safe(expiry or 'не указано')}")
        lines.append(f"RDAP источник: <a href=\"https://rdap.org/domain/{quote(host)}\">открыть запись</a>")
    return "\n".join(lines)

def email_basic_report(email):
    email = email.strip()
    if len(email) > 254 or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        return "Email выглядит некорректным. Проверь формат адреса."
    domain = email.rsplit("@", 1)[1].lower()
    return (
        f"✉️ <b>Проверка email</b>\nАдрес: <code>{safe(email)}</code>\n"
        f"Домен: <code>{safe(domain)}</code>\n"
        "Формат: базовая проверка пройдена.\n"
        "Проверка существования ящика не выполняется: она ненадёжна без подтверждения владельцем."
    )

async def mx_report(email):
    basic = email_basic_report(email)
    if basic.startswith("Email выглядит"):
        return basic
    domain = email.strip().rsplit("@", 1)[1].lower()
    try:
        import dns.resolver
        answers = await asyncio.to_thread(lambda: dns.resolver.resolve(domain, "MX", lifetime=5))
        mx = sorted(str(x.exchange).rstrip(".") for x in answers)
        return basic + "\nMX-записи: " + (", ".join(f"<code>{safe(x)}</code>" for x in mx) if mx else "не найдены")
    except Exception:
        return basic + "\nMX-записи: не удалось проверить (DNS-сервис недоступен или записей нет)."

async def leak_report(email):
    basic = email_basic_report(email)
    if basic.startswith("Email выглядит"):
        return basic
    if not HIBP_API_KEY:
        return basic + (
            "\n\n🛡 <b>Проверка утечек не подключена.</b>\n"
            "Для включения добавь собственный API-ключ Have I Been Pwned в HIBP_API_KEY в файле .env. "
            "Проверяй только адреса, которые принадлежат тебе или на проверку которых есть разрешение."
        )
    url = "https://haveibeenpwned.com/api/v3/breachedaccount/" + quote(email.strip(), safe="")
    headers = {"hibp-api-key": HIBP_API_KEY, "user-agent": "PublicOSINTBot/1.0"}
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url, headers=headers, params={"truncateResponse": "false"},
                                   timeout=aiohttp.ClientTimeout(total=15)) as r:
                if r.status == 200:
                    breaches = await r.json()
                    names = [b.get("Name", "неизвестная утечка") for b in breaches[:15]]
                    return basic + "\n\n⚠️ <b>Сервис сообщает о совпадениях:</b>\n" + "\n".join("• " + safe(n) for n in names)
                if r.status == 404:
                    return basic + "\n\n✅ Сервис не нашёл совпадений в доступном ему наборе данных."
                if r.status == 401:
                    return basic + "\n\nОшибка API-ключа Have I Been Pwned (401)."
                if r.status == 429:
                    return basic + "\n\nЛимит сервиса превышен; попробуй позже."
                return basic + f"\n\nСервис утечек вернул HTTP {r.status}."
        except Exception:
            return basic + "\n\nСервис проверки утечек сейчас недоступен."

def telegram_report(raw):
    value = raw.strip()
    if value.startswith("@"):
        value = value[1:]
    if re.fullmatch(r"[A-Za-z0-9_]{5,32}", value):
        return (
            f"🧭 <b>Публичный Telegram-профиль</b>\n"
            f"Ссылка: <a href=\"https://t.me/{quote(value)}\">https://t.me/{safe(value)}</a>\n\n"
            "Telegram Bot API не позволяет произвольно получать скрытые данные пользователя по одному нику. "
            "Открой ссылку вручную; доступность и принадлежность профиля нужно проверить в Telegram."
        )
    if value.startswith("https://t.me/") or value.startswith("http://t.me/"):
        parsed = urlparse(value)
        if parsed.hostname not in ("t.me", "www.t.me"):
            return "Пришли ник вида @username или ссылку t.me/username."
        return f"🧭 Публичная ссылка Telegram:\n<a href=\"{safe(value)}\">Открыть профиль/канал</a>\nПроверь содержимое вручную в Telegram."
    return "Пришли ник вида @username или публичную ссылку https://t.me/username."

@dp.message(CommandStart())
async def start(message: Message):
    await message.answer(
        "🕵️ <b>OSINT-бот</b>\n\n"
        "Поиск по открытым источникам: ники, базовые сведения о телефонной нумерации, email, домены/IP и публичные Telegram-ссылки.\n\n"
        "Не ищет закрытые базы, домашние адреса, пароли или скрытые данные людей. Выбирай модуль:",
        reply_markup=main_keyboard()
    )

@dp.message(Command("help"))
async def help_cmd(message: Message):
    await message.answer(
        "Выбери модуль в меню. Затем отправь один запрос.\n"
        "/start — главное меню\n/help — помощь\n"
        "Лимит по умолчанию: 8 запросов в минуту на пользователя.\n"
        "Проверяй только данные, которые вправе обрабатывать."
    )

@dp.callback_query(F.data.startswith("mode:"))
async def choose_mode(callback: CallbackQuery):
    mode = callback.data.split(":", 1)[1]
    prompts = {
        "username": "Отправь никнейм без пароля, например example_user.",
        "phone": "Отправь номер в международном формате, например +79991234567.",
        "email": "Отправь email для проверки формата и MX-записей.",
        "domain": "Отправь домен (example.com) или публичный IP-адрес.",
        "telegram": "Отправь @username или публичную ссылку t.me/username.",
        "leaks": "Отправь email, который принадлежит тебе или на проверку которого есть разрешение."
    }
    await callback.message.answer(prompts.get(mode, "Неизвестный модуль."))
    await callback.answer()
    # Set per-user next mode
    pending[callback.from_user.id] = mode

pending = {}

@dp.message(F.text)
async def process_query(message: Message):
    uid = message.from_user.id
    mode = pending.get(uid)
    if not mode:
        await message.answer("Сначала выбери модуль в меню: /start", reply_markup=main_keyboard())
        return
    if not await allowed(message):
        return
    pending.pop(uid, None)
    query = message.text.strip()
    await message.answer("⏳ Проверяю открытые источники…")
    try:
        if mode == "username":
            result = await username_report(query)
        elif mode == "phone":
            result = phone_report(query)
        elif mode == "email":
            result = await mx_report(query)
        elif mode == "domain":
            result = await domain_report(query)
        elif mode == "telegram":
            result = telegram_report(query)
        elif mode == "leaks":
            result = await leak_report(query)
        else:
            result = "Неизвестный модуль. Нажми /start."
        await message.answer(result, parse_mode="HTML", disable_web_page_preview=True, reply_markup=main_keyboard())
    except Exception:
        log.exception("Query processing failed")
        await message.answer("Произошла ошибка при обработке запроса. Попробуй ещё раз позже.", reply_markup=main_keyboard())

@dp.message(Command("stats"))
async def stats(message: Message):
    if message.from_user.id not in ADMIN_IDS:
        await message.answer("Команда доступна только администратору.")
        return
    await message.answer(f"Бот работает. Внутренний лимит: {MAX_PER_MINUTE} запросов/минуту на пользователя.")

async def main():
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
